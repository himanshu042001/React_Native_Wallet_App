import React, { useState } from 'react';
import { View, Text, TouchableOpacity, TextInput, StyleSheet } from 'react-native';

export default function TokenAmount({ navigation }) {
  const [amount, setAmount] = useState('');

  const handleNext = () => {
    // Handle logic for transferring token amount
    console.log('Transfer amount:', amount);
    // Navigate to success screen or previous screen
    navigation.goBack(); // Example to go back, adjust as per your navigation flow
  };

  return (
    <View style={styles.container}>
      <Text style={styles.headerText}>Enter Token Amount</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter amount"
        placeholderTextColor="#ABAFC4"
        onChangeText={text => setAmount(text)}
        value={amount}
        keyboardType="numeric"
      />
      <TouchableOpacity style={styles.nextButton} onPress={handleNext}>
        <Text style={styles.nextButtonText}>Next</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#17171A',
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerText: {
    color: '#FFF',
    fontFamily: 'Poppins',
    fontSize: 24,
    fontWeight: '600',
    marginBottom: 20,
  },
  input: {
    width: 327,
    height: 64,
    padding: 20,
    borderWidth: 1,
    borderColor: '#2A2D3C',
    borderRadius: 8,
    marginBottom: 40,
    color: '#FFF',
    fontFamily: 'Poppins',
    fontSize: 16,
  },
  nextButton: {
    padding: 16,
    backgroundColor: '#5F97FF',
    borderRadius: 4,
    width: 150,
    alignItems: 'center',
  },
  nextButtonText: {
    color: '#FFF',
    fontFamily: 'Poppins',
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 24,
  },
});
