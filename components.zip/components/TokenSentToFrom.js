import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

export default function TokenSentToFrom({ route, navigation }) {
  const { fromAccount, toAccount } = route.params;

  return (
    <View style={styles.container}>
      <Text style={styles.headerText}>Transfer Details</Text>
      
      <View style={styles.accountContainer}>
        <Text style={styles.label}>From Account</Text>
        <Text style={styles.accountText}>{fromAccount.name}</Text>
        <Text style={styles.accountText}>{fromAccount.address}</Text>
      </View>

      <View style={styles.accountContainer}>
        <Text style={styles.label}>To Account</Text>
        <Text style={styles.accountText}>{toAccount.name}</Text>
        <Text style={styles.accountText}>{toAccount.address}</Text>
      </View>

      <TouchableOpacity style={styles.nextButton} onPress={() => navigation.navigate('TokenAmount')}>
        <Text style={styles.nextButtonText}>Next</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#17171A',
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerText: {
    color: '#FFF',
    fontFamily: 'Poppins',
    fontSize: 24,
    fontWeight: '600',
    marginBottom: 20,
  },
  accountContainer: {
    width: 327,
    marginBottom: 16,
  },
  label: {
    color: '#FFF',
    fontFamily: 'Poppins',
    fontSize: 16,
    fontWeight: '600',
    lineHeight: 24,
  },
  accountText: {
    color: '#FFF',
    fontFamily: 'Poppins',
    fontSize: 16,
    lineHeight: 24,
    marginBottom: 8,
  },
  nextButton: {
    marginTop: 40,
    padding: 16,
    backgroundColor: '#5F97FF',
    borderRadius: 4,
  },
  nextButtonText: {
    color: '#FFF',
    fontFamily: 'Poppins',
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 24,
    textAlign: 'center',
  },
});
