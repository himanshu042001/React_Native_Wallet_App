import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image, TextInput, Modal, ScrollView } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';

const mockAccounts = [
  {
    name: 'Account 1',
    address: '0x1234...abcd',
    balance: '19.2371 BNB',
  },
  {
    name: 'Account 2',
    address: '0x5678...efgh',
    balance: '10.1234 ETH',
  },
  {
    name: 'Account 3',
    address: '0x9abc...ijkl',
    balance: '5.4321 ADA',
  },
  
];

export default function SendToken({ navigation }) {
  const [showFromDropdown, setShowFromDropdown] = useState(false);
  const [showToDropdown, setShowToDropdown] = useState(false);
  const [selectedFromAccount, setSelectedFromAccount] = useState(mockAccounts[0]);
  const [selectedToAccount, setSelectedToAccount] = useState(null);

  const toggleFromDropdown = () => {
    setShowFromDropdown(!showFromDropdown);
  };

  const toggleToDropdown = () => {
    setShowToDropdown(!showToDropdown);
  };

  const handleAccountSelect = (account, isFrom) => {
    if (isFrom) {
      setSelectedFromAccount(account);
      setShowFromDropdown(false);
    } else {
      setSelectedToAccount(account);
      setShowToDropdown(false);
      navigation.navigate('TokenSentToFrom', {
        fromAccount: selectedFromAccount,
        toAccount: account,
      });
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.headerText}>Send To</Text>
      <Text style={styles.label}>From</Text>
      <TouchableOpacity style={styles.accountContainer} onPress={toggleFromDropdown}>
        <Image source={require('../assets/dot.png')} style={styles.dotIcon} />
        <View style={styles.accountInfo}>
          <Text style={styles.accountName}>{selectedFromAccount.name}</Text>
          <Text style={styles.accountBalance}>Balance: {selectedFromAccount.balance}</Text>
        </View>
        <FontAwesome name="chevron-down" size={24} color="#FFF" />
      </TouchableOpacity>
      
      <Text style={styles.label}>To</Text>
      <View style={styles.inputContainer}>
        <TextInput style={styles.input} placeholder="Search, public address (0x), or ENS" placeholderTextColor="#ABAFC4" />
        <TouchableOpacity onPress={() => navigation.navigate('Scanner')}>
          <FontAwesome name="qrcode" size={24} color="#FFF" />
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.transferButton} onPress={toggleToDropdown}>
        <Text style={styles.transferButtonText}>Transfer Between My Accounts</Text>
      </TouchableOpacity>

      <Text style={styles.recentText}>Recent</Text>
      <ScrollView>
        {mockAccounts.map((account, index) => (
          <TouchableOpacity key={index} style={styles.accountContainer} onPress={() => handleAccountSelect(account, false)}>
            <Image source={require('../assets/dot.png')} style={styles.dotIcon} />
            <View style={styles.accountInfo}>
              <Text style={styles.accountName}>{account.name}</Text>
              <Text style={styles.accountAddress}>{account.address}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <Modal visible={showFromDropdown || showToDropdown} transparent={true} animationType="slide">
        <View style={styles.modalContainer}>
          <Text style={styles.modalHeaderText}>Select Account</Text>
          {mockAccounts.map((account, index) => (
            <TouchableOpacity key={index} style={styles.accountContainer} onPress={() => handleAccountSelect(account, showFromDropdown)}>
              <Image source={require('../assets/dot.png')} style={styles.dotIcon} />
              <View style={styles.accountInfo}>
                <Text style={styles.accountName}>{account.name}</Text>
                <Text style={styles.accountAddress}>{account.address}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: 375,
    height: 812,
    backgroundColor: '#17171A',
    padding: 20,
  },
  headerText: {
    color: '#FEBF32',
    textAlign: 'center',
    fontFamily: 'Poppins',
    fontSize: 20,
    fontWeight: '800',
    lineHeight: 26,
    marginBottom: 20,
    marginTop:30
  },
  label: {
    color: '#FFF',
    fontFamily: 'Poppins',
    fontSize: 16,
    fontWeight: '600',
    lineHeight: 24,
    marginBottom: 8,
  },
  accountContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    width: 1327,
    padding: 16,
    backgroundColor: '#2A2D3C',
    borderRadius: 8,
    marginBottom: 16,
  },
  dotIcon: {
    width: 24,
    height: 24,
    marginRight: 16,
  },
  accountInfo: {
    flex: 1,
  },
  accountName: {
    color: '#FFF',
    fontFamily: 'Poppins',
    fontSize: 16,
    fontWeight: '600',
    lineHeight: 24,
  },
  accountBalance: {
    color: '#ABAFC4',
    fontFamily: 'Poppins',
    fontSize: 12,
    fontWeight: '400',
    lineHeight: 18,
  },
  accountAddress: {
    color: '#ABAFC4',
    fontFamily: 'Poppins',
    fontSize: 12,
    fontWeight: '400',
    lineHeight: 18,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    width: 327,
    height: 64,
    padding: 20,
    borderWidth: 1,
    borderColor: '#2A2D3C',
    borderRadius: 8,
    marginBottom: 16,
  },
  input: {
    flex: 1,
    color: '#FFF',
    fontFamily: 'Poppins',
    fontSize: 16,
  },
  transferButton: {
    padding: 16,
    alignItems: 'center',
    borderRadius: 4,
  },
  transferButtonText: {
    color: '#5F97FF',
    fontFamily: 'Poppins',
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 24,
    textDecorationLine: 'underline',
  },
  recentText: {
    color: '#ABAFC4',
    fontFamily: 'Poppins',
    fontSize: 16,
    fontWeight: '600',
    lineHeight: 24,
    marginBottom: 16,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    padding: 20,
  },
  modalHeaderText: {
    color: '#FFF',
    textAlign: 'center',
    fontFamily: 'Poppins',
    fontSize: 16,
    fontWeight: '600',
    lineHeight: 24,
    marginBottom: 20,
  },
});
