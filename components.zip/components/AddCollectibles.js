import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';

export default function AddCollectibles() {
  // Placeholder data (simulating blockchain data)
  const blockchainData = {
    address: '0xBBB6A79A12945aC14C84185a17C6983B...',
    id: 77,
  };

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Add Asset</Text>

      <View style={styles.section}>
        <Text style={styles.label}>Address</Text>
        <Text style={styles.addressText}>{blockchainData.address}</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.label}>ID</Text>
        <Text style={styles.idText}>{blockchainData.id}</Text>
      </View>

      <TouchableOpacity style={styles.addButton}>
        <Text style={styles.buttonText}>Add</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    width: 375,
    height: 812,
    flexDirection: 'column',
    justifyContent: 'flex-end',
    alignItems: 'center',
    gap: 8,
    flexShrink: 0,
    backgroundColor: '#17171A',
    padding:100
     
  },
  heading: {
    color: '#FEBF32',
    textAlign: 'center',
    fontVariantNumeric: 'lining-nums proportional-nums',
    fontFamily: 'Poppins',
    fontSize: 26,
    fontWeight: '900',
  
    marginTop: 20,
    marginBottom: 300,

  },
  section: {
    width: 327,
    padding: 12,
    flexDirection: 'column',
    alignItems: 'flex-start',
    borderRadius: 8,
    borderColor: '#2A2D3C',
    borderWidth: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.00)',
    marginBottom: 8,
  },
  label: {
    color: '#888DAA',
    fontVariantNumeric: 'lining-nums proportional-nums',
    fontFamily: 'Poppins',
    fontSize: 12,
    fontWeight: '400',
    lineHeight: 16, // 133.333%
  },
  addressText: {
    color: '#FFF',
    fontVariantNumeric: 'lining-nums proportional-nums',
    fontFamily: 'Poppins',
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 24, // 171.429%
    marginTop: 4,
  },
  idText: {
    color: '#FFF',
    fontVariantNumeric: 'lining-nums proportional-nums',
    fontFamily: 'Poppins',
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 24, // 171.429%
    marginTop: 4,
  },
  addButton: {
    width: 327,
    paddingVertical: 12,
    paddingHorizontal: 16,
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    flexShrink: 0,
    borderRadius: 8,
    backgroundColor: '#FEBF32',
    marginTop: 16,
  },
  buttonText: {
    color: '#000',
    fontVariantNumeric: 'lining-nums proportional-nums',
    fontFamily: 'Poppins',
    fontSize: 16,
    fontWeight: '600',
    lineHeight: 24, // 150%
  },
});
